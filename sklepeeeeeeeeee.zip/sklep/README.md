# ChemiaMax — Kiosk: sklep z chemią gospodarczą + pętla reklam wideo

Projekt wykonany w 100% w katalogu `Kk/`, zgodnie z [zadaniem 1800](https://mdview.t24.ovh/task/LINUX/zadanie1800).

**Potwierdzenie:** przeczytałem całą instrukcję z linku (Części 1–5: instalacja Ubuntu Server w VirtualBox, środowisko kiosku, dnsmasq whitelist+blacklist, zabezpieczenia, zarządzanie SSH) — wszystkie kroki są zautomatyzowane w `install.sh`.

> 📖 **Szczegółowa instrukcja uruchomienia krok po kroku (także dla szkolnego komputera z VirtualBox):** [INSTRUKCJA_URUCHOMIENIA.md](INSTRUKCJA_URUCHOMIENIA.md)
> 📧 **Najprostsza droga (katalog mailem → szkoła → VS Code → jeden skrót klawiszowy):** [INSTRUKCJA_EMAIL_VSCODE.md](INSTRUKCJA_EMAIL_VSCODE.md)

---

## 1. Szybki start (test na dowolnej maszynie)

```bash
cd Kk/sklep
bash start.sh
```

**Na Windows (szkolny komputer) — bez pisania komend:**

- podwójne kliknięcie **`URUCHOM.bat`** — sam sprawdzi Node.js, zainstaluje biblioteki i otworzy przeglądarkę,
- albo w VS Code: otwórz ten folder i naciśnij **Ctrl + Shift + B** (zatrzymanie: Terminal → Uruchom zadanie… → STOP SKLEP).

**Albo klasycznie** (`npm install` + `npm start`). Skrypt `start.sh` sam doinstalowuje Node.js, gdy go brak:

```bash
cd Kk/sklep
bash start.sh          # sklep na localhost
bash start.sh lan      # sklep widoczny z sieci (http://IP_MASZYNY:3000)
bash start.sh restart  # restart sklepu
bash start.sh stop     # zatrzymanie
```

Otwórz **http://localhost:3000** — działa sklep, a reklama w pętli rusza po 60 s (dostosuj w `public/index.html`, stałe `REKLAMA_CO_SEKUND` / `REKLAMA_MIN_CZAS`).

> Wideo reklamowe skopiowane z `public (1).zip` → `Kk/sklep/videos/` (3 pliki mp4).
> Wrzucaj kolejne spoty do `Kk/sklep/videos/` — serwer sam je wykryje (`.mp4`, `.webm`, `.ogg`, `.mov`...).

---

## 2. Znaleziony i naprawiony błąd IP (plik `public (1).zip`)

Podejrzewałeś adresy IP — **potwierdzone**, błąd miał dwa źródła:

| # | Problem w oryginale | Naprawa w `Kk/sklep/` |
|---|---|---|
| 1 | `app.listen(PORT, () => ...)` **bez jawnego hosta**. Node 17+ sam wybiera interfejs wg kolejności DNS — na VM-ach z niepełnym `/etc/hosts` (brak wpisu `127.0.0.1 localhost`) serwer wstawał z `EADDRNOTAVAIL` albo nasłuchiwał tylko na IPv6 `::1`, więc „strona nie działała”. | Jawne `app.listen(PORT, "127.0.0.1")` + **automatyczny fallback na `0.0.0.0`**, gdyby localhost był zablokowany. |
| 2 | Frontend/API mogły trafić na sztywne adresy (bezwzględne URL-e przy `fetch`). | **Wyłącznie ścieżki względne** (`/api/videos`, `/api/zamow`, `/videos/...`) — zero adresów IP w kodzie; strona zawsze rozmawia z serwerem, z którego została wczytana. |

Dodatkowo: `os.networkInterfaces()` w `try/catch` (środowiska bez dostępu do listy interfejsów).

---

## 3. Co zawiera sklep (JavaScript, zero CDN — działa offline)

- **Katalog chemii gospodarczej** — 14 produktów, 6 kategorii, filtrowanie (pranie, naczynia, powierzchnie, łazienka, dezynfekcja, akcesoria)
- **Koszyk** — zmiana ilości, suma liczona **po stronie serwera** (klient wysyła tylko `id` + `sztuki`)
- **Zamówienia** — `POST /api/zamow` z walidacją i numerem `ZAM-XXXX`; log na serwerze
- **Reklama w pętli** — cykl *sklep 60 s → reklama wideo 20 s → sklep → ...* (badge „REKLAMA”, odtwarzacz z ZIP-a z obsługą `Range`/przewijania)
- **Stream wideo** — `/api/videos` + `express.static` z `Range: 206` (przewijanie działa)

---

## 4. Pełna instalacja kiosku na VM (zadanie 1800)

Na **Ubuntu Server w VirtualBox** (zadania 1–4 z instrukcji robisz ręcznie: ISO, VM z bridged adapter, instalacja, SSH):

```bash
scp -r Kk/sklep admin@<adres-ip-vm>:~/
ssh admin@<adres-ip-vm>
cd ~/sklep && sudo bash install.sh    # wykonuje Części 2–5 instrukcji
```

`install.sh` robi automatycznie: pakiety (xorg, openbox, chromium, lightdm, unclutter), użytkownik `kiosk`, auto-login LightDM, autostart Chromium `--kiosk` na `http://localhost:3000`, Node 20 + **autostart sklepu przez systemd** (`kiosk-sklep.service` → `start.sh restart`; log: `/var/log/kiosk-sklep.log`), dnsmasq (biała lista + czarna + `address=/#/`), blokada skrótów (`rc.xml`), maskowanie TTY, watchdog Chromium, hartowanie SSH (`PermitRootLogin no`, `AllowUsers admin`, banner) + instaluje narzędzia `kiosk-dns`, `kiosk-status` i `kiosk-info` (status.sh).

Skrypty zarządzania (zadania 22–23): `kiosk-dns` (allow/block/remove/list/test), `kiosk-status` (raport z instrukcji), `status.sh` / `kiosk-info` (szybki status jednym poleceniem) oraz **`kiosk-dns-report`** (zadanie dodatkowe 5: Top blokowanych/dozwolonych domen DNS; `--instaluj` = cron o północy → `/var/log/kiosk-dns-daily.log`).

> **Uwaga DNŚ:** sklep działa na `localhost:3000`, a Chromium łączy się z `localhost` — to nie przechodzi przez DNS, więc **tryb zamknięty dnsmasq nie blokuje sklepu**. Reklamy też są lokalne. Dodaj domeny do białej listy tylko jeśli chcesz w kiosku dodatkowe strony zewnętrzne.

Po restarcie VM: kiosk → Chromium → **sklep z pętlą reklamową**. ✅

---

## 5. Struktura

```
Kk/
├── Info, Zadanie                # pliki wejściowe
├── public (1).zip               # oryginalny skrypt (z błędem IP)
├── _zip_extract/                # rozpakowany ZIP (referencja)
└── sklep/                       # ← NOWY PROJEKT
    ├── server.js                # Express: sklep + API + wideo; HOST=localhost (naprawa)
    ├── produkty.js              # katalog (serwer) — ceny liczone na serwerze
    ├── public/index.html        # sklep + pętla reklam (ścieżki względne — naprawa)
    ├── videos/                  # 3 spoty z ZIP-a (podmień na własne)
    ├── start.sh                 # JEDNO polecenie: Node + biblioteki + sklep
    ├── status.sh                # status: sklep + kiosk + DNS (kolorowy raport)
    ├── test_czysty_ubuntu.sh    # test instalacyjny start.sh od zera (T0–T9)
    ├── install.sh               # automatyzacja zadania 1800 (Części 2–5)
    ├── kopiuj_wideo.sh          # kopiuje wideo z ZIP-a
    ├── kiosk-dns, kiosk-status  # narzędzia SSH (zadania 22–23)
    ├── kiosk-dns-report         # dzienny raport blokowanych domen DNS (zad. dod. 5)
    ├── URUCHOM.bat              # Windows: podwójne kliknięcie = start sklepu
    ├── .vscode/tasks.json       # VS Code: Ctrl+Shift+B = start, STOP SKLEP = stop
    └── README.md
```

## 6. Testy wykonane

| Test | Wynik |
|---|---|
| `GET /` (strona sklepu) | **HTTP 200**, 20 KB |
| `GET /api/produkty` | 14 produktów + 7 kategorii (JSON) |
| `GET /api/videos` | 3 pliki mp4 (URL-encode polskich nazw) |
| `GET /videos/...` z `Range` | **HTTP 206** (streaming/przewijanie OK) |
| `POST /api/zamow` | suma `40.97 PLN` liczona serwerowo |
| `POST /api/zamow` (błędne id) | odrzucone: `Nieznany produkt: hakier` ✅ |
| Fallback IP | brak `EADDRNOTAVAIL` — jawny host + awaryjny `0.0.0.0` |
| `bash -n` install.sh / start.sh / status.sh / kiosk-dns / kiosk-status / kopiuj_wideo.sh | składnia poprawna ✅ |
| `status.sh` przy działającym sklepie | SKLEP [OK], produkty 21 pozycji, reklamy 3 ✅ |
| `test_czysty_ubuntu.sh` (pełny scenariusz od zera: T0–T9) | **20 PASS / 0 FAIL / 0 WARN** (52 s) ✅ |
| `kiosk-dns-report --test` (Top domen, poziom blokowania) | facebook.com 3×, blokada 75% ✅ |
| `node --check` server.js / produkty.js | składnia poprawna ✅ |
